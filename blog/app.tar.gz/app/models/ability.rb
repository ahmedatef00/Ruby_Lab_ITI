class Ability
    include CanCan::Ability
  
    def initialize(user)
      can :read, Post
      can :read, Comment
      return unless user.present?
      can :create, Post
      can :update, Post, user_id: user.id
      can :destroy, Post, user_id: user.id
      can :update, Comment, user_id: user.id
      can :create, Comment